create function audit_archivage() returns trigger
    language plpgsql
as
$$
declare
    pourcentage numeric;

BEGIN
    pourcentage = (new.sommecollecte / new.bute) * 100;
    RAISE NOTICE 'pourcentage %',pourcentage;

    IF (TG_OP = 'DELETE') THEN
--         INSERT INTO emp_audit SELECT 'D', now(), user, OLD.*;
--         RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        if (pourcentage <= 0) then
            insert into archivagestatue(projet_id, ts, projetstatue_id) values (new.id, current_timestamp, 1);
        elsif (pourcentage > 1 and pourcentage < 10) then
            insert into archivagestatue(projet_id, ts, projetstatue_id) values (new.id, current_timestamp, 2);
        elsif (pourcentage > 10 and pourcentage < 50) then
            insert into archivagestatue(projet_id, ts, projetstatue_id) values (new.id, current_timestamp, 3);
        elsif (pourcentage = 50) then
            insert into archivagestatue(projet_id, ts, projetstatue_id) values (new.id, current_timestamp, 4);
        elsif (pourcentage >50 and pourcentage<100 ) then
            insert into archivagestatue(projet_id, ts, projetstatue_id) values (new.id, current_timestamp, 5);
        elsif (pourcentage >= 100) then
            insert into archivagestatue(projet_id, ts, projetstatue_id) values (new.id, current_timestamp, 6);
        end if;
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        insert into archivagestatue(projet_id, ts, projetstatue_id) values (new.id, current_timestamp, 1);
        RETURN NEW;
    END IF;
    RETURN NULL; -- le résultat est ignoré car il s'agit d'un trigger AFTER
END;
$$;

alter function audit_archivage() owner to postgres;

