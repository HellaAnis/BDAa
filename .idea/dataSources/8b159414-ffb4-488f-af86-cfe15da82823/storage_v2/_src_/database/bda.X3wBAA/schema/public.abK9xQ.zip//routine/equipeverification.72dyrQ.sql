create function equipeverification() returns trigger
    language plpgsql
as
$$
DECLARE
    myrec integer;
    val   integer;
    equipeUtlisateur varchar(15);
BEGIN

    val = new.utilisateur_id;

    SELECT participer.equipe_id into myrec
    FROM participer
    WHERE participer.utilisateur_id = val;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'utilisateur % not found',myrec;
    END IF;

    select nomequipe into equipeUtlisateur from equipe where equipe.id = new.equipe_id;
    IF myrec <> new.equipe_id THEN
        RAISE EXCEPTION 'l utilisateur n est pas un membre de l equipe --> %', equipeUtlisateur
            USING HINT = 'Il doit etre un membre de cette equipe ';
    ELSE
        RAISE NOTICE 'Equipe de l ulilisateur est %',equipeUtlisateur;
    END IF;

    RETURN NEW;
END;
$$;

alter function equipeverification() owner to postgres;

