create function rembourcement() returns trigger
    language plpgsql
as
$$
DECLARE
    r investissement%ROWTYPE;
    val            integer;
    roleUtlisateur varchar(15);
BEGIN

    FOR r IN
        SELECT *
        FROM investissement m
        where  m.projet_id=old.id
        ORDER BY m.id, m.utilisateur_id
--     select investissement.id into from investissement where investissement.utilisateur_id = 1;
    LOOP
--     delete from investissement where investissement.id=r.id;
    raise notice 'id % ',r.id;

    if old.sommecollecte < old.bute then
    insert into rembourcement (sommerembource, ts, utilisateur_id) values
                    (r.sommeengage,now(),r.utilisateur_id);
    end if;

    delete from investissement where investissement.id = r.id;

    END LOOP;


    RETURN old;
END;
$$;

alter function rembourcement() owner to postgres;

