create function historique() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
--     IF (new.bute <> OLD.bute) or (NEW.datefin <> OLD.datefin) THEN
        insert into parametres(datefin, bute, ts, projet_id) values (new.datefin, new.bute, current_timestamp, new.id);
--     end if;
    RETURN NEW;

END;
$$;

alter function historique() owner to postgres;

