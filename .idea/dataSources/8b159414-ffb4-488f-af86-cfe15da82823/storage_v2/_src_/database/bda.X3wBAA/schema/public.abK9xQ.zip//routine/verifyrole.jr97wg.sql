create function verifyrole() returns trigger
    language plpgsql
as
$$
DECLARE
    myrec          integer;
    val            integer;
    roleUtlisateur varchar(15);
BEGIN

    val = new.utilisateur_id;

    SELECT participer.role_id into myrec
    FROM participer
    WHERE participer.utilisateur_id = val;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'utilisateur % not found',myrec;
    END IF;

    select role.role into roleUtlisateur from role where role.id = myrec;

    IF myrec <> 1 THEN
        RAISE EXCEPTION 'le role du créateur de ce projet est --> %', roleUtlisateur
            USING HINT = 'Le role d un createur du projet doit etre chef ';
    ELSE
        RAISE NOTICE 'le role de l utilisateur est CHEF';
    END IF;

    RETURN NEW;
END;
$$;

alter function verifyrole() owner to postgres;

