create function audit_projet() returns trigger
    language plpgsql
as
$$
DECLARE
    commission    numeric;
    sommecollecte numeric;

BEGIN

    IF (TG_OP = 'DELETE') THEN
        RAISE NOTICE 'DELETE %',old.id;
        delete from parametres where parametres.projet_id = old.id;
        delete from archivagestatue where archivagestatue.projet_id =old.id;
        if old.sommecollecte < 0 then
            raise exception 'vous devez payer voter commision avant de supprimer votre projet';
        end if;
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        RAISE NOTICE 'UPDATE';
        RAISE NOTICE '%',old.sommecollecte;
        RAISE NOTICE '%',old.commission;
        RAISE NOTICE '%',old.bute;
        commission = (new.bute * 5) / 100;
        new.commission = commission;
        new.sommecollecte = new.sommecollecte - (commission - old.commission);
        RAISE NOTICE 'La commission de se projet est : --> %€', commission;
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        RAISE NOTICE 'INSERT';
        commission = ((new.bute) * 5) / 100;
        new.investiseuractuel = 0;
        new.projetstatue_id = 1;
        new.commission = commission;
        new.sommecollecte = -commission;
        RAISE NOTICE 'La nouvelle commission de se projet est : --> %€', commission;
        RETURN NEW;
    END IF;
    RETURN NULL;
    -- le résultat est ignoré car il s'agit d'un trigger AFTER
END;
$$;

alter function audit_projet() owner to postgres;

