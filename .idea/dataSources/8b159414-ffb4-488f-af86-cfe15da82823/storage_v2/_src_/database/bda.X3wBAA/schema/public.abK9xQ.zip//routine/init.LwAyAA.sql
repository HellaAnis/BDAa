create function init() returns trigger
    language plpgsql
as
$$
DECLARE
    commission numeric;

BEGIN

    commission =(new.bute*5)/100;
    new.investiseuractuel =0;
    new.projetstatue_id =1;
    new.commission = commission;
    new.sommecollecte =-commission;

    RAISE NOTICE 'La commission de se projet est : --> % £', commission;


    RETURN NEW;
END;
$$;

alter function init() owner to postgres;

